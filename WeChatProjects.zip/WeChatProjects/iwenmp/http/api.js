module.exports={
  getSession:'/api/mp/getSession',
  login:"/api/mp/login",
  binding:"/api/mp/binding",
  fasong:"/api/mp/fasong"
} 