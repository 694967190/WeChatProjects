module.exports = {
    mp:{
      appId:'wx82e84dcec5d80258',
      appSecret:'3d4639579875d2c8d2f07d90dad8c778'
    }
  }